package com.epf.rentmanager.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Vehicule {
    private int id;
    private String constructeur;
    private String modele;
    private byte nbPlaces;

    public Vehicule(int id, String constructeur, String modele, byte nbPlaces) {
        this.id = id;
        this.constructeur = constructeur;
        this.modele = modele;
        this.nbPlaces = nbPlaces;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getConstructeur() {
        return constructeur;
    }

    public void setConstructeur(String constructeur) {
        this.constructeur = constructeur;
    }

    public String getModele() {
        return modele;
    }

    public void setModele(String modele) {
        this.modele = modele;
    }

    public byte getNbPlaces() {
        return nbPlaces;
    }

    public void setNbPlaces(byte nbPlaces) {
        this.nbPlaces = nbPlaces;
    }

    @Override
    public String toString() {
        return "Vehicule" +
                "id=" + id +
                ", constructeur" + constructeur +
                ", modele" + modele+
                ", nbPlace" + nbPlaces +
                '}';
    }
}