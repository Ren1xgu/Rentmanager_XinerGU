package com.epf.rentmanager.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.epf.rentmanager.persistence.ConnectionManager;

public class ReservationDao {
	private int id;
	private int client_id;
	private int vehicle_id;
	private LocalDate debut;
	private LocalDate fin;

	public ReservationDao(int id, int client_id, int vehicle_id, LocalDate debut, LocalDate fin) {
		this.id = id;
		this.client_id = client_id;
		this.vehicle_id = vehicle_id;
		this.debut = debut;
		this.fin = fin;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getClient_id() {
		return client_id;
	}

	public void setClient_id(int client_id) {
		this.client_id = client_id;
	}

	public int getVehicle_id() {
		return vehicle_id;
	}

	public void setVehicle_id(int vehicle_id) {
		this.vehicle_id = vehicle_id;
	}

	public LocalDate getDebut() {
		return debut;
	}

	public void setDebut(LocalDate debut) {
		this.debut = debut;
	}

	public LocalDate getFin() {
		return fin;
	}

	public void setFin(LocalDate fin) {
		this.fin = fin;
	}

	@Override
	public String toString() {
		return "Reservation{" +
				"id=" + id +
				", client_id=" + client_id +
				", vehicle_id=" + vehicle_id +
				", debut=" + debut +
				", fin=" + fin +
				'}';
	}

	private Connection connection;

	public ReservationDao(Connection connection) {
		this.connection = connection;
	}

	public void createReservation(Reservation reservation) throws DaoException {
		String query = "INSERT INTO Reservation (client_id, vehicle_id, debut, fin) VALUES (?, ?, ?, ?)";
		try (PreparedStatement statement = connection.prepareStatement(query)) {
			statement.setInt(1, reservation.getClient().getId());
			statement.setInt(2, reservation.getVehicule().getId());
			statement.setObject(3, reservation.getDebut());
			statement.setObject(4, reservation.getFin());
			statement.executeUpdate();
		} catch (SQLException e) {
			throw new DaoException("Erreur lors de la création de la réservation", e);
		}
	}

	public List<Reservation> getAllReservations() throws DaoException {
		List<Reservation> reservations = new ArrayList<>();
		String query = "SELECT * FROM Reservation";
		try (PreparedStatement statement = connection.prepareStatement(query);
			 ResultSet resultSet = statement.executeQuery()) {
			while (resultSet.next()) {
				int id = resultSet.getInt("id");
				int clientId = resultSet.getInt("client_id");
				int vehiculeId = resultSet.getInt("vehicle_id");
				LocalDateTime debut = resultSet.getObject("debut", LocalDateTime.class);
				LocalDateTime fin = resultSet.getObject("fin", LocalDateTime.class);
				ClientDao clientDao = new ClientDao(connection);
				VehiculeDao vehiculeDao = new VehiculeDao(connection);
				Client client = clientDao.getClientById(clientId);
				Vehicule vehicule = vehiculeDao.getVehiculeById(vehiculeId);
				reservations.add(new Reservation(id, client, vehicule, debut, fin));
			}
		} catch (SQLException e) {
			throw new DaoException("Erreur lors de la récupération des réservations", e);
		}
		return reservations;
	}

	private Reservation mapResultSetToReservation(ResultSet rs) throws SQLException {
		int id = rs.getInt("id");
		int client_id = rs.getInt("client_id");
		int vehicle_id = rs.getInt("vehicle_id");
		LocalDate debut = rs.getDate("debut").toLocalDate();
		LocalDate fin = rs.getDate("fin").toLocalDate();
		return new Reservation(id, client_id, vehicle_id, debut, fin);
	}

	public void createReservation(Reservation reservation) throws ServiceException {
		try {
			reservationDao.createReservation(reservation);
		} catch (DaoException e) {
			throw new ServiceException("Erreur lors de la création de la réservation", e);
		}
	}

	public List<Reservation> getAllReservations() throws ServiceException {
		try {
			return reservationDao.getAllReservations();
		} catch (DaoException e) {
			throw new ServiceException("Erreur lors de la récupération des réservations", e);
		}

	private static ReservationDao instance = null;
	private ReservationDao() {}
	public static ReservationDao getInstance() {
		if(instance == null) {
			instance = new ReservationDao();
		}
		return instance;
	}
	
	private static final String CREATE_RESERVATION_QUERY = "INSERT INTO Reservation(client_id, vehicle_id, debut, fin) VALUES(?, ?, ?, ?);";
	private static final String DELETE_RESERVATION_QUERY = "DELETE FROM Reservation WHERE id=?;";
	private static final String FIND_RESERVATIONS_BY_CLIENT_QUERY = "SELECT id, vehicle_id, debut, fin FROM Reservation WHERE client_id=?;";
	private static final String FIND_RESERVATIONS_BY_VEHICLE_QUERY = "SELECT id, client_id, debut, fin FROM Reservation WHERE vehicle_id=?;";
	private static final String FIND_RESERVATIONS_QUERY = "SELECT id, client_id, vehicle_id, debut, fin FROM Reservation;";
		
	public long create(Reservation reservation) throws DaoException {
		return 0;
	}
	
	public long delete(Reservation reservation) throws DaoException {
		return 0;
	}

	
	public List<Reservation> findResaByClientId(long clientId) throws DaoException {
		return new ArrayList<Reservation>();
	}
	
	public List<Reservation> findResaByVehicleId(long vehicleId) throws DaoException {
		return new ArrayList<Reservation>();
	}

	public List<Reservation> findAll() throws DaoException {
		return new ArrayList<Reservation>();
	}
}
