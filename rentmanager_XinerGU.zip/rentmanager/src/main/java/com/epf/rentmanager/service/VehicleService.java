package com.epf.rentmanager.service;

public class VehicleService {
    private VehicleDao vehicleDao;

    public VehicleService(VehicleDao vehicleDao) {
        this.vehicleDao = vehicleDao;
    }

    public void createOrUpdateVehicule(Vehicule vehicule) throws ServiceException {
        if (vehicule.getConstructeur().isEmpty()) {
            throw new ServiceException("Le constructeur du véhicule ne peut pas être vide");
        }

        if (vehicule.getNbPlaces() <= 1) {
            throw new ServiceException("Le nombre de places du véhicule doit être supérieur à 1");
        }

    }

    public int countVehicles() throws ServiceException {
        try {
            return vehiculeDao.count();
        } catch (DaoException e) {
            throw new ServiceException("Error counting vehicles", e);
        }
    }

}

