package com.epf.rentmanager.ui.cli;

package ui.cli;

        package ui.cli;

import dao.ClientDao;
import dao.ReservationDao;
import dao.VehiculeDao;
import model.Client;
import model.Reservation;
import model.Vehicule;
import service.ClientService;
import service.ReservationService;
import service.ServiceException;
import service.VehiculeService;
import utils.IOUtils;

import java.time.LocalDateTime;
import java.util.List

public class CommandLineInterface {
    private final ClientService clientService;
    private final VehiculeService vehiculeService;
    private final ReservationService reservationService;


    public CommandLineInterface(ClientDao clientDao, VehiculeDao vehiculeDao) {
        this.clientService = new ClientService(clientDao);
        this.vehiculeService = new VehiculeService(vehiculeDao);
        this.reservationService = new ReservationService(reservationDao);
    }

    public void start() {
        boolean running = true;
        while (running) {
            displayMenu();
            String choice = IOUtils.readString("Choix: ");
            switch (choice) {
                case "1":
                    createClient();
                    break;
                case "2":
                    listClients();
                    break;
                case "3":
                    createVehicule();
                    break;
                case "4":
                    listVehicules();
                    break;
                case "5":
                    deleteClient();
                    break;
                case "6":
                    deleteVehicule();
                    break;
                case "7":
                    createReservation();
                    break;
                case "q":
                    running = false;
                    break;
                default:
                    System.out.println("Choix invalide, veuillez réessayer.");
            }
        }
    }

    private void displayMenu() {
        System.out.println("Menu:");
        System.out.println("1. Créer un client");
        System.out.println("2. Lister tous les clients");
        System.out.println("3. Créer un véhicule");
        System.out.println("4. Lister tous les véhicules");
        System.out.println("5. Supprimer un client");
        System.out.println("6. Supprimer un véhicule");
        System.out.println("7. Créer une réservation");
        System.out.println("q. Quitter");
    }

    private void createClient() {
        try {
            System.out.println("Création d'un client:");
            String nom = IOUtils.readString("Nom: ");
            String prenom = IOUtils.readString("Prénom: ");
            String email = IOUtils.readEmail("Email: ");
            LocalDate naissance = IOUtils.readDate("Date de naissance (format YYYY-MM-DD): ");
            clientService.createClient(new Client(0, nom, prenom, email, naissance));
            System.out.println("Client créé avec succès.");
        } catch (ServiceException e) {
            System.out.println("Erreur lors de la création du client: " + e.getMessage());
        }
    }

    private void listClients() {
        List<Client> clients = clientService.getAllClients();
        if (clients.isEmpty()) {
            System.out.println("Aucun client trouvé.");
        } else {
            System.out.println("Liste des clients:");
            for (Client client : clients) {
                System.out.println(client);
            }
        }
    }

    private void createVehicule() {
        try {
            System.out.println("Création d'un véhicule:");
            String constructeur = IOUtils.readString("Constructeur: ");
            String modele = IOUtils.readString("Modèle: ");
            int nbPlaces = IOUtils.readInt("Nombre de places: ");
            vehiculeService.createVehicule(new Vehicule(0, constructeur, modele, nbPlaces));
            System.out.println("Véhicule créé avec succès.");
        } catch (ServiceException e) {
            System.out.println("Erreur lors de la création du véhicule: " + e.getMessage());
        }
    }

    private void listVehicules() {
        List<Vehicule> vehicules = vehiculeService.getAllVehicules();
        if (vehicules.isEmpty()) {
            System.out.println("Aucun véhicule trouvé.");
        } else {
            System.out.println("Liste des véhicules:");
            for (Vehicule vehicule : vehicules) {
                System.out.println(vehicule);
            }
        }
    }

    private void deleteClient() {
        try {
            int id = IOUtils.readInt("ID du client à supprimer: ");
            clientService.deleteClient(id);
            System.out.println("Client supprimé avec succès.");
        } catch (ServiceException e) {
            System.out.println("Erreur lors de la suppression du client: " + e.getMessage());
        }
    }

    private void deleteVehicule() {
        try {
            int id = IOUtils.readInt("ID du véhicule à supprimer: ");
            vehiculeService.deleteVehicule(id);
            System.out.println("Véhicule supprimé avec succès.");
        } catch (ServiceException e) {
            System.out.println("Erreur lors de la suppression du véhicule: " + e.getMessage());
        }
    }

    private void createReservation() {
        try {
            System.out.println("Création d'une réservation:");
            int clientId = IOUtils.readInt("ID du client: ");
            Client client = clientService.getClientById(clientId);
            int vehiculeId = IOUtils.readInt("ID du véhicule: ");
            Vehicule vehicule = vehiculeService.getVehiculeById(vehiculeId);
            LocalDateTime debut = IOUtils.readDateTime("Date et heure de début (format YYYY-MM-DD HH:MM): ");
            LocalDateTime fin = IOUtils.readDateTime("Date et heure de fin (format YYYY-MM-DD HH:MM): ");
            reservationService.createReservation(new Reservation(0, client, vehicule, debut, fin));
            System.out.println("Réservation créée avec succès.");
        } catch (ServiceException e) {
            System.out.println("Erreur lors de la création de la réservation: " + e.getMessage());
        }
    }

    private void listReservations() {
        List<Reservation> reservations = reservationService.getAllReservations();
        if (reservations.isEmpty()) {
            System.out.println("Aucune réservation trouvée.");
        } else {
            System.out.println("Liste des réservations:");
            for (Reservation reservation : reservations) {
                System.out.println(reservation);
            }
        }
    }

    private void listReservationsByClient() {
        try {
            int clientId = IOUtils.readInt("ID du client: ");
            List<Reservation> reservations = reservationService.getReservationsByClientId(clientId);
            if (reservations.isEmpty()) {
                System.out.println("Aucune réservation trouvée pour ce client.");
            } else {
                System.out.println("Liste des réservations pour ce client:");
                for (Reservation reservation : reservations) {
                    System.out.println(reservation);
                }
            }
        } catch (ServiceException e) {
            System.out.println("Erreur lors de la récupération des réservations pour ce client: " + e.getMessage());
        }
    }

    private void listReservationsByVehicule() {
        try {
            int vehiculeId = IOUtils.readInt("ID du véhicule: ");
            List<Reservation> reservations = reservationService.getReservationsByVehiculeId(vehiculeId);
            if (reservations.isEmpty()) {
                System.out.println("Aucune réservation trouvée pour ce véhicule.");
            } else {
                System.out.println("Liste des réservations pour ce véhicule:");
                for (Reservation reservation : reservations) {
                    System.out.println(reservation);
                }
            }
        } catch (ServiceException e) {
            System.out.println("Erreur lors de la récupération des réservations pour ce véhicule: " + e.getMessage());
        }
    }

    private void deleteReservation() {
        try {
            int reservationId = IOUtils.readInt("ID de la réservation à supprimer: ");
            reservationService.deleteReservation(reservationId);
            System.out.println("Réservation supprimée avec succès.");
        } catch (ServiceException e) {
            System.out.println("Erreur lors de la suppression de la réservation: " + e.getMessage());
        }
    }
}
