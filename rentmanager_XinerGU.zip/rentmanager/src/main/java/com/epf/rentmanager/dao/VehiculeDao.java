package com.epf.rentmanager.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VehiculeDao {
	private Connection connection;

	public VehiculeDao(Connection connection) {
		this.connection = connection;
	}

	public List<Vehicule> getAllVehicules() throws DaoException {
		List<Vehicule> vehicules = new ArrayList<>();
		String query = "SELECT * FROM Vehicule";
		try (PreparedStatement statement = connection.prepareStatement(query);
			 ResultSet resultSet = statement.executeQuery()) {
			while (resultSet.next()) {
				int id = resultSet.getInt("id");
				String constructeur = resultSet.getString("constructeur");
				String modele = resultSet.getString("modele");
				byte nbPlaces = resultSet.getByte("nb_places");
				vehicules.add(new Vehicule(id, constructeur, modele, nbPlaces));
			}
		} catch (SQLException e) {
			throw new DaoException("Erreur lors de la récupération des véhicules", e);
		}
		return vehicules;
	}

	public int count() throws DaoException {
		String query = "SELECT COUNT(*) AS vehicle_count FROM Vehicule";
		try (PreparedStatement statement = connection.prepareStatement(query);
			 ResultSet resultSet = statement.executeQuery()) {
			if (resultSet.next()) {
				return resultSet.getInt("vehicle_count");
			}
			return 0; // Pas de résultat trouvé
		} catch (SQLException e) {
			throw new DaoException("Error counting vehicles", e);
		}
	}

}
