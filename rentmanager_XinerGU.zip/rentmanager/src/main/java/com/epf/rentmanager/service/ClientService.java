package com.epf.rentmanager.service;

import java.util.List;

public class ClientService {
    private ClientDao clientDao;

    public ClientService(ClientDao clientDao) {
        this.clientDao = clientDao;
    }

    public void createOrUpdateClient(Client client) throws ServiceException {
        if (client.getNom().isEmpty() || client.getPrenom().isEmpty()) {
            throw new ServiceException("Le nom et le prénom du client ne peuvent pas être vides");
        }

        client.setNom(client.getNom().toUpperCase());

    }

}


