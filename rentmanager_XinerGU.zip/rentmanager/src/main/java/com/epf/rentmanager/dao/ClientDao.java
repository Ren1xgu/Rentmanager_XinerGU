package com.epf.rentmanager.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.time.LocalDate;

public class ClientDao {
	private Connection connection;

	public ClientDao(Connection connection) {
		this.connection = connection;
	}

	public List<Client> getAllClients() throws DaoException {
		List<Client> clients = new ArrayList<>();
		String query = "SELECT * FROM Client";
		try (PreparedStatement statement = connection.prepareStatement(query);
			 ResultSet resultSet = statement.executeQuery()) {
			while (resultSet.next()) {
				int id = resultSet.getInt("id");
				String nom = resultSet.getString("nom");
				String prenom = resultSet.getString("prenom");
				String email = resultSet.getString("email");
				LocalDate naissance = resultSet.getDate("naissance").toLocalDate();
				clients.add(new Client(id, nom, prenom, email, naissance));
			}
		} catch (SQLException e) {
			throw new DaoException("Erreur lors de la récupération des clients", e);
		}
		return clients;
	}

}

