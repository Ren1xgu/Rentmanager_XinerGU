import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/vehicle/list")
public class VehicleListServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final VehiculeService vehiculeService;

    public VehicleListServlet() {
        super();
        // Initialize the service
        this.vehiculeService = new VehiculeService(new VehiculeDao(/* pass your DAO instance here */));
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            List<Vehicule> vehicles = vehiculeService.getAllVehicules();
            request.setAttribute("vehicles", vehicles);
            // Forward to the JSP page
            request.getRequestDispatcher("/WEB-INF/views/vehicle/list.jsp").forward(request, response);
        } catch (ServiceException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error fetching vehicle list.");
        }
    }
}
